#include "Carrera.h"

Carrera::Carrera()
{
	codigo_de_la_carrera = 0;
}

Carrera::Carrera(string Nombre_De_Carrera, int codigo_de_la_carrera, string facultad, string duraciom, string materia)
{
	this->Nombre_De_Carrera = Nombre_De_Carrera;
	this->codigo_de_la_carrera = codigo_de_la_carrera;
	this->facultad = facultad;
	this->duraciom = duraciom;
	this->materia = materia;
	
	
}

void Carrera::Leer_datos_Carrera()
{
	cout << "Ingrese el Nombre_De_Carrera ";
	cin >> Nombre_De_Carrera;
	cout << "Ingrese el codigo_de_la_carrera ";
	cin >> codigo_de_la_carrera;
	cout << "Ingrese la facultad: ";
	cin >> facultad;
	cout << "Ingrese la duraciom: ";
	cin >> duraciom;
}

void Carrera::Mostrar_Datos_Carrera()
{
	cout << "Nombre_De_Carrera: " << Nombre_De_Carrera << endl;
	cout << "codigo_de_la_carrera: " << codigo_de_la_carrera << endl;
	cout << "facultad: " << facultad << endl;
	cout << "duraciom: " << duraciom << endl;
	cout << "materias" << materia << endl;
}

int Carrera::buscar_Carrera(int codigo_De_Carrera)
{
	if (codigo_de_la_carrera == codigo_De_Carrera)
	{
		return true;
	}
	else
	{
		return false;
	}
}
