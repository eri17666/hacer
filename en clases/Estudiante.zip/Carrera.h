#pragma once
#include <iostream> // cin, cout
#include <string>	// para cadenas
using namespace std;
class Carrera
{
public:
	Carrera();
	Carrera(string Nombre_De_Carrera, int codigo_de_la_carrera, string facultad, string duraciom,string materia);
	void Leer_datos_Carrera();
	void Mostrar_Datos_Carrera();
	int buscar_Carrera(int codigo_De_Carrera);

private:
	string Nombre_De_Carrera;
	int codigo_de_la_carrera=0;
	string facultad;
	string duraciom;
	string materia;
};

